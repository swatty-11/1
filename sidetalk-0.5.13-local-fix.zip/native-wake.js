(() => {
  const WAKE_EVENT = "chatgpt-side-branch:native-wake";
  const BRIDGE_KEY = "__chatgptSideBranchNativeWake";
  const previousBridge = window[BRIDGE_KEY];
  let inheritedSchedulerBridge = null;
  if (previousBridge && typeof previousBridge.dispose === "function") {
    inheritedSchedulerBridge = previousBridge.dispose({
      preserveMessageBridge: true,
      preserveTimeoutBridge: true,
      preserveIntersectionBridge: true,
      preserveResizeBridge: true,
      preserveIdleBridge: true,
      preserveSchedulerBridge: true
    });
  } else if (typeof previousBridge === "function") {
    document.removeEventListener(WAKE_EVENT, previousBridge, true);
  }

  const findDocumentGetter = (name) => {
    let prototype = Object.getPrototypeOf(document);
    while (prototype) {
      const getter = Object.getOwnPropertyDescriptor(prototype, name)?.get;
      if (getter) return getter;
      prototype = Object.getPrototypeOf(prototype);
    }
    return null;
  };
  const nativeHiddenGetter = findDocumentGetter("hidden");
  const nativeVisibilityGetter = findDocumentGetter("visibilityState");
  const nativeRequestAnimationFrame = window.requestAnimationFrame.bind(window);
  const nativeCancelAnimationFrame = window.cancelAnimationFrame.bind(window);
  const nativeMessageChannel =
    inheritedSchedulerBridge?.nativeMessageChannel || window.MessageChannel;
  const nativeSetTimeout =
    inheritedSchedulerBridge?.nativeSetTimeout || window.setTimeout.bind(window);
  const nativeClearTimeout =
    inheritedSchedulerBridge?.nativeClearTimeout || window.clearTimeout.bind(window);
  const nativeIntersectionObserver =
    inheritedSchedulerBridge?.nativeIntersectionObserver || window.IntersectionObserver;
  const nativeResizeObserver =
    inheritedSchedulerBridge?.nativeResizeObserver || window.ResizeObserver;
  const nativeRequestIdleCallback =
    inheritedSchedulerBridge?.nativeRequestIdleCallback ||
    window.requestIdleCallback?.bind(window);
  const nativeCancelIdleCallback =
    inheritedSchedulerBridge?.nativeCancelIdleCallback ||
    window.cancelIdleCallback?.bind(window);
  const nativeScheduler = inheritedSchedulerBridge?.nativeScheduler || window.scheduler;
  const nativeSchedulerPostTask =
    inheritedSchedulerBridge?.nativeSchedulerPostTask || nativeScheduler?.postTask;
  const nativeSchedulerYield =
    inheritedSchedulerBridge?.nativeSchedulerYield || nativeScheduler?.yield;
  let restoreTimer = 0;
  let foregroundPump = 0;
  let restoreVisibility = null;
  let virtualForeground = false;
  let nextVirtualFrameId = -1;
  const virtualFrames = new Map();
  const virtualMessageRecords =
    inheritedSchedulerBridge?.records || new Set();
  const virtualTimeoutRecords =
    inheritedSchedulerBridge?.timeoutRecords || new Map();
  const virtualIntersectionRecords =
    inheritedSchedulerBridge?.intersectionRecords || new Set();
  const virtualResizeRecords =
    inheritedSchedulerBridge?.resizeRecords || new Set();
  const virtualIdleRecords = inheritedSchedulerBridge?.idleRecords || new Map();
  const virtualPostTaskRecords =
    inheritedSchedulerBridge?.postTaskRecords || new Set();
  const virtualSchedulerYieldRecords =
    inheritedSchedulerBridge?.schedulerYieldRecords || new Set();
  let schedulerBridgeInstalled =
    inheritedSchedulerBridge?.schedulerBridgeInstalled === true;

  const intersectionState = (record, entry) => ({
    isIntersecting: entry.isIntersecting,
    thresholdIndex: (record.observer.thresholds || [0])
      .filter((threshold) => threshold <= entry.intersectionRatio).length
  });

  const reportAsyncError = (error) => {
    queueMicrotask(() => {
      throw error;
    });
  };

  const callMessageHandler = (record, event) => {
    const handler = record.handler;
    if (!handler) return;
    try {
      if (typeof handler === "function") {
        handler.call(record.port1, event);
      } else {
        handler.handleEvent(event);
      }
    } catch (error) {
      reportAsyncError(error);
    }
  };

  const makeMessageEvent = (data) => {
    try {
      return new MessageEvent("message", { data });
    } catch {
      const event = new Event("message");
      Object.defineProperty(event, "data", { configurable: true, value: data });
      return event;
    }
  };

  if (!inheritedSchedulerBridge?.nativeSetTimeout) {
    window.setTimeout = (handler, delay = 0, ...args) => {
      const numericDelay = Number(delay);
      const boundedDelay = Number.isFinite(numericDelay)
        ? Math.max(0, numericDelay)
        : 0;
      let timerId = 0;
      const record = {
        dueAt: Date.now() + boundedDelay,
        run: null
      };
      record.run = () => {
        if (virtualTimeoutRecords.get(timerId) !== record) return;
        virtualTimeoutRecords.delete(timerId);
        try {
          if (typeof handler === "function") {
            handler.apply(window, args);
          } else {
            window.eval(String(handler));
          }
        } catch (error) {
          reportAsyncError(error);
        }
      };
      timerId = nativeSetTimeout(record.run, boundedDelay);
      virtualTimeoutRecords.set(timerId, record);
      return timerId;
    };
    window.clearTimeout = (timerId) => {
      virtualTimeoutRecords.delete(timerId);
      nativeClearTimeout(timerId);
    };
  }

  if (!inheritedSchedulerBridge?.nativeMessageChannel && typeof nativeMessageChannel === "function") {
    const WrappedMessageChannel = function () {
      const channel = new nativeMessageChannel();
      const { port1, port2 } = channel;
      const nativePostMessage = port2.postMessage.bind(port2);
      const nativePort1Close = port1.close.bind(port1);
      const nativePort2Close = port2.close.bind(port2);
      const record = {
        port1,
        port2,
        handler: null,
        pending: [],
        suppressNative: 0,
        closed: false,
        nativePostMessage,
        nativePort1Close,
        nativePort2Close,
        nativeListener: null
      };

      record.nativeListener = (event) => {
        if (record.closed) return;
        if (record.pending.length > 0) record.pending.shift();
        if (record.suppressNative > 0) {
          record.suppressNative -= 1;
          return;
        }
        callMessageHandler(record, event);
      };
      try {
        port1.addEventListener("message", record.nativeListener);
        port1.start?.();
        Object.defineProperty(port1, "onmessage", {
          configurable: true,
          enumerable: true,
          get: () => record.handler,
          set: (handler) => {
            record.handler =
              typeof handler === "function" || typeof handler?.handleEvent === "function"
                ? handler
                : null;
          }
        });
        port2.postMessage = (data, transfer) => {
          record.pending.push(data);
          if (transfer === undefined) nativePostMessage(data);
          else nativePostMessage(data, transfer);
        };
        const close = (nativeClose) => () => {
          record.closed = true;
          record.pending.length = 0;
          virtualMessageRecords.delete(record);
          nativeClose();
        };
        port1.close = close(nativePort1Close);
        port2.close = close(nativePort2Close);
        virtualMessageRecords.add(record);
      } catch {
        // MessagePort instances are normally extensible. If a Chromium build
        // locks them down, leave this channel completely native rather than
        // risking ChatGPT's scheduler.
        port1.removeEventListener("message", record.nativeListener);
        try {
          delete port1.onmessage;
          port2.postMessage = nativePostMessage;
          port1.close = nativePort1Close;
          port2.close = nativePort2Close;
        } catch {
          // The original channel remains usable through its prototype methods.
        }
      }
      return channel;
    };
    WrappedMessageChannel.prototype = nativeMessageChannel.prototype;
    window.MessageChannel = WrappedMessageChannel;
  }

  if (
    !inheritedSchedulerBridge?.nativeIntersectionObserver &&
    typeof nativeIntersectionObserver === "function"
  ) {
    const WrappedIntersectionObserver = function (callback, options) {
      if (typeof callback !== "function") return new nativeIntersectionObserver(callback, options);
      let record;
      const observer = new nativeIntersectionObserver((entries, nativeObserver) => {
        for (const entry of entries) {
          record?.states.set(entry.target, intersectionState(record, entry));
        }
        callback.call(nativeObserver, entries, nativeObserver);
      }, options);
      const nativeObserve = observer.observe.bind(observer);
      const nativeUnobserve = observer.unobserve.bind(observer);
      const nativeDisconnect = observer.disconnect.bind(observer);
      record = {
        observer,
        callback,
        options,
        targets: new Set(),
        states: new Map(),
        nativeObserve,
        nativeUnobserve,
        nativeDisconnect
      };
      observer.observe = (target) => {
        const result = nativeObserve(target);
        record.targets.add(target);
        virtualIntersectionRecords.add(record);
        return result;
      };
      observer.unobserve = (target) => {
        record.targets.delete(target);
        record.states.delete(target);
        return nativeUnobserve(target);
      };
      observer.disconnect = () => {
        record.targets.clear();
        record.states.clear();
        virtualIntersectionRecords.delete(record);
        return nativeDisconnect();
      };
      virtualIntersectionRecords.add(record);
      return observer;
    };
    WrappedIntersectionObserver.prototype = nativeIntersectionObserver.prototype;
    Object.setPrototypeOf(WrappedIntersectionObserver, nativeIntersectionObserver);
    window.IntersectionObserver = WrappedIntersectionObserver;
  }

  if (
    !inheritedSchedulerBridge?.nativeResizeObserver &&
    typeof nativeResizeObserver === "function"
  ) {
    const WrappedResizeObserver = function (callback) {
      if (typeof callback !== "function") return new nativeResizeObserver(callback);
      let record;
      const observer = new nativeResizeObserver((entries, nativeObserver) => {
        for (const entry of entries) {
          const rect = entry.target.getBoundingClientRect();
          record?.sizes.set(entry.target, { width: rect.width, height: rect.height });
        }
        callback.call(nativeObserver, entries, nativeObserver);
      });
      const nativeObserve = observer.observe.bind(observer);
      const nativeUnobserve = observer.unobserve.bind(observer);
      const nativeDisconnect = observer.disconnect.bind(observer);
      record = {
        observer,
        callback,
        targets: new Set(),
        sizes: new Map(),
        nativeObserve,
        nativeUnobserve,
        nativeDisconnect
      };
      observer.observe = (target, options) => {
        const result = nativeObserve(target, options);
        record.targets.add(target);
        virtualResizeRecords.add(record);
        return result;
      };
      observer.unobserve = (target) => {
        record.targets.delete(target);
        record.sizes.delete(target);
        return nativeUnobserve(target);
      };
      observer.disconnect = () => {
        record.targets.clear();
        record.sizes.clear();
        virtualResizeRecords.delete(record);
        return nativeDisconnect();
      };
      virtualResizeRecords.add(record);
      return observer;
    };
    WrappedResizeObserver.prototype = nativeResizeObserver.prototype;
    Object.setPrototypeOf(WrappedResizeObserver, nativeResizeObserver);
    window.ResizeObserver = WrappedResizeObserver;
  }

  if (
    !inheritedSchedulerBridge?.nativeRequestIdleCallback &&
    typeof nativeRequestIdleCallback === "function"
  ) {
    window.requestIdleCallback = (callback, options) => {
      let idleId = 0;
      const record = {
        callback,
        run: null
      };
      record.run = (deadline) => {
        if (virtualIdleRecords.get(idleId) !== record) return;
        virtualIdleRecords.delete(idleId);
        callback(deadline);
      };
      idleId = nativeRequestIdleCallback(record.run, options);
      virtualIdleRecords.set(idleId, record);
      return idleId;
    };
    window.cancelIdleCallback = (idleId) => {
      virtualIdleRecords.delete(idleId);
      nativeCancelIdleCallback?.(idleId);
    };
  }

  if (
    !inheritedSchedulerBridge?.nativeSchedulerPostTask &&
    nativeScheduler &&
    typeof nativeSchedulerPostTask === "function"
  ) {
    try {
      nativeScheduler.postTask = (callback, options) => {
        if (typeof callback !== "function") {
          return nativeSchedulerPostTask.call(nativeScheduler, callback, options);
        }
        const scheduledAt = performance.now();
        let resolveTask;
        let rejectTask;
        const managedPromise = new Promise((resolve, reject) => {
          resolveTask = resolve;
          rejectTask = reject;
        });
        const record = {
          callback,
          resolve: resolveTask,
          reject: rejectTask,
          started: false,
          signal: null,
          dueAt: Infinity,
          ready: false,
          abortListener: null,
          run: null
        };
        const cleanup = () => {
          virtualPostTaskRecords.delete(record);
          if (record.signal && record.abortListener) {
            record.signal.removeEventListener("abort", record.abortListener);
          }
        };
        record.run = () => {
          if (record.started) return undefined;
          record.started = true;
          cleanup();
          if (record.signal?.aborted) {
            record.reject(
              record.signal.reason || new DOMException("The task was aborted.", "AbortError")
            );
            return undefined;
          }
          try {
            const result = callback();
            Promise.resolve(result).then(record.resolve, record.reject);
            return result;
          } catch (error) {
            record.reject(error);
            throw error;
          }
        };
        // Native validation runs before the task is eligible for a synthetic
        // wake, including a rejected options promise and synchronous errors.
        const nativeTask = nativeSchedulerPostTask.call(nativeScheduler, record.run, options);
        try {
          // Leave accessors, inherited dictionaries, and coercion to the native
          // scheduler. Inspecting data descriptors does not invoke option getters.
          const descriptors = options && typeof options === "object" &&
            [Object.prototype, null].includes(Object.getPrototypeOf(options))
            ? Object.getOwnPropertyDescriptors(options) : null;
          const simpleOptions = options == null || descriptors &&
            Object.values(descriptors).every((descriptor) => "value" in descriptor);
          const delay = descriptors?.delay?.value ?? 0;
          const signal = descriptors?.signal?.value;
          const knownSignal = signal == null || typeof AbortSignal === "function" && signal instanceof AbortSignal;
          if (simpleOptions && knownSignal && typeof delay === "number" && Number.isFinite(delay) && delay >= 0) {
            record.dueAt = scheduledAt + delay;
            record.signal = signal || null;
          }
        } catch {
          // A proxy dictionary can reject inspection. Its task stays native.
        }
        if (record.signal && typeof record.signal.addEventListener === "function") {
          record.abortListener = () => {
            if (record.started) return;
            record.started = true;
            cleanup();
            record.reject(
              record.signal.reason || new DOMException("The task was aborted.", "AbortError")
            );
          };
          record.signal.addEventListener("abort", record.abortListener, { once: true });
        }
        if (!record.started) virtualPostTaskRecords.add(record);
        Promise.resolve(nativeTask).catch((error) => {
          if (record.started) return;
          record.started = true;
          cleanup();
          record.reject(error);
        });
        Promise.resolve().then(() => { record.ready = true; });
        return managedPromise;
      };

      if (typeof nativeSchedulerYield === "function") {
        nativeScheduler.yield = (options) => {
          let resolveYield;
          let rejectYield;
          const managedPromise = new Promise((resolve, reject) => {
            resolveYield = resolve;
            rejectYield = reject;
          });
          const record = {
            settled: false,
            resolve: resolveYield,
            reject: rejectYield,
            run: null
          };
          const settle = (error) => {
            if (record.settled) return;
            record.settled = true;
            virtualSchedulerYieldRecords.delete(record);
            if (error === undefined) record.resolve();
            else record.reject(error);
          };
          record.run = () => settle();
          virtualSchedulerYieldRecords.add(record);
          Promise.resolve(nativeSchedulerYield.call(nativeScheduler, options)).then(
            () => settle(),
            (error) => settle(error)
          );
          return managedPromise;
        };
      }
      schedulerBridgeInstalled = true;
    } catch {
      // Scheduling methods can be read-only in experimental Chromium builds.
      // Keep their native implementation instead of breaking page startup.
      schedulerBridgeInstalled = false;
    }
  }

  const isActuallyHidden = () => {
    try {
      if (nativeHiddenGetter) return Boolean(nativeHiddenGetter.call(document));
      if (nativeVisibilityGetter) {
        return nativeVisibilityGetter.call(document) === "hidden";
      }
    } catch {
      // Fall back to the exposed value when the browser changes its prototype.
    }
    return document.visibilityState === "hidden";
  };

  window.requestAnimationFrame = (callback) => {
    if (!virtualForeground || !isActuallyHidden()) {
      return nativeRequestAnimationFrame(callback);
    }
    const id = nextVirtualFrameId--;
    virtualFrames.set(id, callback);
    return id;
  };

  window.cancelAnimationFrame = (id) => {
    if (virtualFrames.delete(id)) return;
    nativeCancelAnimationFrame(id);
  };

  const flushVirtualFrames = () => {
    const callbacks = [...virtualFrames.values()];
    virtualFrames.clear();
    const timestamp = performance.now();
    callbacks.forEach((callback) => {
      try {
        callback(timestamp);
      } catch (error) {
        reportAsyncError(error);
      }
    });
  };

  const flushVirtualMessages = (budget = 64) => {
    let remaining = budget;
    for (const record of [...virtualMessageRecords]) {
      while (
        remaining > 0 &&
        !record.closed &&
        record.handler &&
        record.pending.length > 0
      ) {
        const data = record.pending.shift();
        record.suppressNative += 1;
        callMessageHandler(record, makeMessageEvent(data));
        remaining -= 1;
      }
      if (remaining === 0) break;
    }
    return budget - remaining;
  };

  const flushDueTimeouts = (budget = 64) => {
    let remaining = budget;
    const now = Date.now();
    for (const [timerId, record] of [...virtualTimeoutRecords]) {
      if (remaining === 0) break;
      if (!record || record.dueAt > now || typeof record.run !== "function") {
        continue;
      }
      nativeClearTimeout(timerId);
      record.run();
      remaining -= 1;
    }
    return budget - remaining;
  };

  const flushVirtualIntersections = (budget = 64) => {
    let remaining = budget;
    for (const record of [...virtualIntersectionRecords]) {
      if (remaining === 0) break;
      const root = record.options?.root;
      const rootRect =
        root instanceof Element
          ? root.getBoundingClientRect()
          : {
              top: 0,
              left: 0,
              right: window.innerWidth,
              bottom: window.innerHeight,
              width: window.innerWidth,
              height: window.innerHeight,
              x: 0,
              y: 0,
              toJSON: () => ({})
            };
      const entries = [];
      for (const target of [...record.targets]) {
        if (remaining === 0) break;
        if (!(target instanceof Element) || !target.isConnected) {
          record.targets.delete(target);
          record.states?.delete(target);
          continue;
        }
        const rect = target.getBoundingClientRect();
        const left = Math.max(rect.left, rootRect.left);
        const right = Math.min(rect.right, rootRect.right);
        const top = Math.max(rect.top, rootRect.top);
        const bottom = Math.min(rect.bottom, rootRect.bottom);
        const intersects = right >= left && bottom >= top;
        const width = intersects ? Math.max(0, right - left) : 0;
        const height = intersects ? Math.max(0, bottom - top) : 0;
        const targetArea = Math.max(0, rect.width * rect.height);
        const entry = {
          time: performance.now(),
          target,
          rootBounds: rootRect,
          boundingClientRect: rect,
          intersectionRect: {
            top,
            left,
            right: left + width,
            bottom: top + height,
            width,
            height,
            x: left,
            y: top,
            toJSON: () => ({})
          },
          isIntersecting: intersects,
          intersectionRatio: targetArea > 0 ? (width * height) / targetArea : intersects ? 1 : 0
        };
        // Replaying an unchanged sentinel can repeatedly start native history
        // pagination. Share transition state with native observer deliveries.
        const state = intersectionState(record, entry);
        const previous = record.states?.get(target);
        record.states ||= new Map();
        record.states.set(target, state);
        if (!previous || previous.isIntersecting !== state.isIntersecting ||
            previous.thresholdIndex !== state.thresholdIndex) entries.push(entry);
        remaining -= 1;
      }
      if (entries.length > 0) {
        try {
          record.callback.call(record.observer, entries, record.observer);
        } catch (error) {
          reportAsyncError(error);
        }
      }
    }
    return budget - remaining;
  };

  const flushVirtualResizes = (budget = 64) => {
    let remaining = budget;
    for (const record of [...virtualResizeRecords]) {
      if (remaining === 0) break;
      const entries = [];
      for (const target of [...record.targets]) {
        if (remaining === 0) break;
        if (!(target instanceof Element) || !target.isConnected) {
          record.targets.delete(target);
          record.sizes?.delete(target);
          continue;
        }
        const rect = target.getBoundingClientRect();
        const previous = record.sizes?.get(target);
        record.sizes ||= new Map();
        record.sizes.set(target, { width: rect.width, height: rect.height });
        remaining -= 1;
        if (previous?.width === rect.width && previous?.height === rect.height) continue;
        const size = { inlineSize: rect.width, blockSize: rect.height };
        entries.push({
          target,
          contentRect: rect,
          borderBoxSize: [size],
          contentBoxSize: [size],
          devicePixelContentBoxSize: [size]
        });
      }
      if (entries.length > 0) {
        try {
          record.callback.call(record.observer, entries, record.observer);
        } catch (error) {
          reportAsyncError(error);
        }
      }
    }
    return budget - remaining;
  };

  const flushVirtualIdleCallbacks = (budget = 64) => {
    let remaining = budget;
    for (const [idleId, record] of [...virtualIdleRecords]) {
      if (remaining === 0) break;
      nativeCancelIdleCallback?.(idleId);
      try {
        record.run({
          didTimeout: false,
          timeRemaining: () => 50
        });
      } catch (error) {
        reportAsyncError(error);
      }
      remaining -= 1;
    }
    return budget - remaining;
  };

  const flushVirtualSchedulerWork = (budget = 64) => {
    let remaining = budget;
    for (const record of [...virtualPostTaskRecords]) {
      if (remaining === 0) break;
      if (!record.ready || record.dueAt > performance.now()) continue;
      try {
        record.run();
      } catch (error) {
        reportAsyncError(error);
      }
      remaining -= 1;
    }
    for (const record of [...virtualSchedulerYieldRecords]) {
      if (remaining === 0) break;
      record.run();
      remaining -= 1;
    }
    return budget - remaining;
  };

  const flushVirtualWork = () => {
    // React can alternate MessageChannel tasks and animation frames while
    // committing a streamed answer. A few bounded passes advance that work
    // without allowing a runaway queue to monopolize the page.
    for (let pass = 0; pass < 4; pass += 1) {
      const timeoutCount = flushDueTimeouts();
      const intersectionCount = pass === 0 ? flushVirtualIntersections() : 0;
      const resizeCount = pass === 0 ? flushVirtualResizes() : 0;
      const idleCount = flushVirtualIdleCallbacks();
      const schedulerCount = flushVirtualSchedulerWork();
      const messageCount = flushVirtualMessages();
      const frameCount = virtualFrames.size;
      flushVirtualFrames();
      if (
        timeoutCount === 0 &&
        intersectionCount === 0 &&
        resizeCount === 0 &&
        idleCount === 0 &&
        schedulerCount === 0 &&
        messageCount === 0 &&
        frameCount === 0
      ) break;
    }
  };

  const isScrollable = (element) => {
    if (!(element instanceof HTMLElement)) return false;
    if (element.scrollHeight <= element.clientHeight + 2) return false;
    try {
      return /auto|scroll|overlay/i.test(getComputedStyle(element).overflowY);
    } catch {
      return false;
    }
  };

  const findConversationScroller = () => {
    // Current ChatGPT builds scroll an inner conversation surface rather than
    // document.scrollingElement. Long replies remain virtualized at the old
    // viewport until this exact surface receives a bottom/scroll pass.
    const anchors = [
      ...document.querySelectorAll(
        'main [data-message-author-role], main [data-testid*="conversation-turn"], main article, [role="main"] [data-message-author-role]'
      )
    ];
    for (let index = anchors.length - 1; index >= 0; index -= 1) {
      let current = anchors[index]?.parentElement || null;
      while (
        current &&
        current !== document.body &&
        current !== document.documentElement
      ) {
        // A code block can scroll inside a turn. It is not the history viewport.
        if (isScrollable(current) && !current.closest('article, [data-message-author-role], [data-testid*="conversation-turn"]')) return current;
        current = current.parentElement;
      }
    }

    // The composer is often a sibling of the history surface. During a React
    // remount there may be no turns to anchor the ancestor search at all.
    const main = document.querySelector('main, [role="main"]');
    if (main) {
      const candidates = [main, ...main.querySelectorAll("div, section")]
        .filter((element) => isScrollable(element) &&
          !element.closest('article, [data-message-author-role], [data-testid*="conversation-turn"]'));
      candidates.sort((left, right) => right.clientHeight - left.clientHeight);
      if (candidates[0]) return candidates[0];
    }

    // Accessible-heading-only layouts can omit semantic turn wrappers. Walk
    // upward from the composer and choose the nearest scrollable app surface.
    const composer = document.querySelector(
      'textarea[placeholder], form [contenteditable="true"][role="textbox"], form [contenteditable="true"], [contenteditable="true"][role="textbox"]'
    );
    let current = composer?.parentElement || null;
    while (
      current &&
      current !== document.body &&
      current !== document.documentElement
    ) {
      if (isScrollable(current)) return current;
      current = current.parentElement;
    }
    return null;
  };

  const pulseConversationViewport = () => {
    // Discovery reads older lineage/initialization turns. Keep its native
    // search anchor and explicit scan position while still flushing frames.
    const preservePosition = new URLSearchParams(window.location.search).get("sidetalk_cloud_discovery") === "1";
    const scrollers = new Set();
    const conversationScroller = findConversationScroller();
    if (conversationScroller) scrollers.add(conversationScroller);
    if (document.scrollingElement instanceof HTMLElement) {
      scrollers.add(document.scrollingElement);
    }
    for (const scroller of scrollers) {
      const previousTop = scroller.scrollTop;
      if (!preservePosition && previousTop + scroller.clientHeight < scroller.scrollHeight - 2) {
        scroller.scrollTop = scroller.scrollHeight;
      }
      void scroller.getBoundingClientRect();
      if (scroller.scrollTop !== previousTop) {
        scroller.dispatchEvent(new Event("scroll", { bubbles: true }));
      }
    }
  };

  const releaseQueuedFrames = () => {
    const callbacks = [...virtualFrames.values()];
    virtualFrames.clear();
    callbacks.forEach((callback) => nativeRequestAnimationFrame(callback));
  };

  const restore = () => {
    restoreTimer = 0;
    window.clearInterval(foregroundPump);
    foregroundPump = 0;
    restoreVisibility?.();
    restoreVisibility = null;
    virtualForeground = false;
    releaseQueuedFrames();
  };

  const wake = () => {
    if (!isActuallyHidden()) {
      restore();
      return;
    }

    virtualForeground = true;
    if (!foregroundPump) {
      foregroundPump = window.setInterval(() => {
        if (virtualForeground && isActuallyHidden()) {
          pulseConversationViewport();
          flushVirtualWork();
        }
      }, 125);
    }
    if (!restoreVisibility) {
      const hiddenDescriptor = Object.getOwnPropertyDescriptor(document, "hidden");
      const stateDescriptor = Object.getOwnPropertyDescriptor(
        document,
        "visibilityState"
      );
      const focusDescriptor = Object.getOwnPropertyDescriptor(document, "hasFocus");
      try {
        Object.defineProperty(document, "hidden", {
          configurable: true,
          get: () => false
        });
        Object.defineProperty(document, "visibilityState", {
          configurable: true,
          get: () => "visible"
        });
        Object.defineProperty(document, "hasFocus", {
          configurable: true,
          value: () => true
        });
        restoreVisibility = () => {
          try {
            if (hiddenDescriptor) {
              Object.defineProperty(document, "hidden", hiddenDescriptor);
            } else {
              delete document.hidden;
            }
            if (stateDescriptor) {
              Object.defineProperty(document, "visibilityState", stateDescriptor);
            } else {
              delete document.visibilityState;
            }
            if (focusDescriptor) {
              Object.defineProperty(document, "hasFocus", focusDescriptor);
            } else {
              delete document.hasFocus;
            }
          } catch {
            // ChatGPT remains usable even if a browser makes these native
            // accessors non-configurable after the temporary wake.
          }
        };
      } catch {
        restoreVisibility = () => undefined;
      }
    }

    // ChatGPT defers parts of its streamed React tree while a tab is hidden.
    // Replay the same lifecycle signals it consumes when a user focuses the
    // tab, without actually activating or exposing the native Branch tab.
    window.dispatchEvent(new Event("focus"));
    document.dispatchEvent(new Event("visibilitychange"));
    window.dispatchEvent(new Event("resize"));

    // ChatGPT virtualizes long conversations and final cited answers. Force a
    // layout/scroll pass and execute the rAF work Chromium would otherwise
    // withhold until the Branch tab is activated.
    pulseConversationViewport();
    flushVirtualWork();

    window.clearTimeout(restoreTimer);
    restoreTimer = window.setTimeout(restore, 2_000);
  };

  wake.dispose = (options = {}) => {
    window.clearTimeout(restoreTimer);
    window.clearInterval(foregroundPump);
    document.removeEventListener(WAKE_EVENT, wake, true);
    restore();
    window.requestAnimationFrame = nativeRequestAnimationFrame;
    window.cancelAnimationFrame = nativeCancelAnimationFrame;
    if (
      options.preserveMessageBridge ||
      options.preserveTimeoutBridge ||
      options.preserveIntersectionBridge ||
      options.preserveResizeBridge ||
      options.preserveIdleBridge ||
      options.preserveSchedulerBridge
    ) {
      return {
        nativeMessageChannel,
        records: virtualMessageRecords,
        nativeSetTimeout,
        nativeClearTimeout,
        timeoutRecords: virtualTimeoutRecords,
        nativeIntersectionObserver,
        intersectionRecords: virtualIntersectionRecords,
        nativeResizeObserver,
        resizeRecords: virtualResizeRecords,
        nativeRequestIdleCallback,
        nativeCancelIdleCallback,
        idleRecords: virtualIdleRecords,
        nativeScheduler,
        nativeSchedulerPostTask,
        nativeSchedulerYield,
        postTaskRecords: virtualPostTaskRecords,
        schedulerYieldRecords: virtualSchedulerYieldRecords,
        schedulerBridgeInstalled
      };
    }
    if (typeof nativeMessageChannel === "function") {
      window.MessageChannel = nativeMessageChannel;
    }
    for (const record of virtualMessageRecords) {
      record.port1.removeEventListener("message", record.nativeListener);
      record.port2.postMessage = record.nativePostMessage;
      record.port1.close = record.nativePort1Close;
      record.port2.close = record.nativePort2Close;
      try {
        delete record.port1.onmessage;
        record.port1.onmessage = record.handler;
      } catch {
        // The port continues to deliver natively if a browser locks the field.
      }
    }
    virtualMessageRecords.clear();
    if (typeof nativeIntersectionObserver === "function") {
      window.IntersectionObserver = nativeIntersectionObserver;
    }
    for (const record of virtualIntersectionRecords) {
      record.observer.observe = record.nativeObserve;
      record.observer.unobserve = record.nativeUnobserve;
      record.observer.disconnect = record.nativeDisconnect;
    }
    virtualIntersectionRecords.clear();
    if (typeof nativeResizeObserver === "function") {
      window.ResizeObserver = nativeResizeObserver;
    }
    for (const record of virtualResizeRecords) {
      record.observer.observe = record.nativeObserve;
      record.observer.unobserve = record.nativeUnobserve;
      record.observer.disconnect = record.nativeDisconnect;
    }
    virtualResizeRecords.clear();
    if (typeof nativeRequestIdleCallback === "function") {
      window.requestIdleCallback = nativeRequestIdleCallback;
    }
    if (typeof nativeCancelIdleCallback === "function") {
      window.cancelIdleCallback = nativeCancelIdleCallback;
    }
    virtualIdleRecords.clear();
    if (schedulerBridgeInstalled && nativeScheduler) {
      if (typeof nativeSchedulerPostTask === "function") {
        nativeScheduler.postTask = nativeSchedulerPostTask;
      }
      if (typeof nativeSchedulerYield === "function") {
        nativeScheduler.yield = nativeSchedulerYield;
      }
    }
    virtualPostTaskRecords.clear();
    virtualSchedulerYieldRecords.clear();
    window.setTimeout = nativeSetTimeout;
    window.clearTimeout = nativeClearTimeout;
    return null;
  };

  window[BRIDGE_KEY] = wake;
  document.addEventListener(WAKE_EVENT, wake, true);
})();
