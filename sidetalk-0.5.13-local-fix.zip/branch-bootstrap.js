(() => {
  const BOOTSTRAP_WINDOW_NAME_PREFIX = "__chatgptSideBranchBootstrap:";
  const pageUrl = new URL(window.location.href);
  const branchId = pageUrl.searchParams.get("branchId") || "";
  const targetValue = pageUrl.searchParams.get("target") || "";
  if (!/^[A-Za-z0-9:_-]{1,200}$/.test(branchId) || !targetValue) return;

  try {
    const target = new URL(targetValue);
    const isNativeBranchRoute = /^\/branch\/[^/]+\/[^/]+\/?$/i.test(
      target.pathname
    );
    if (
      target.origin !== "https://chatgpt.com" ||
      target.username ||
      target.password ||
      !isNativeBranchRoute
    ) {
      return;
    }
    target.hash = "";
    window.name = `${BOOTSTRAP_WINDOW_NAME_PREFIX}${branchId}`;
    window.location.replace(target.href);
  } catch {
    // Invalid or tampered startup parameters remain on this inert local page.
  }
})();
