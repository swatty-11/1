# SideTalk 0.5.13 local diagnostic fix

This is an unpacked copy of the Chrome Web Store build, kept separate from the installed extension.

## Changes

- Ordinary `chatgpt.com` conversations no longer require the assistant card's “More actions” button before SideTalk records the branch point. The native `/branch/{conversation}/{message}` route remains the creation mechanism.
- If the visible-answer DOM check times out, an ordinary conversation may use SideTalk's existing, page-local native conversation snapshot only when its current node is a completed assistant message. This supplies the exact native message ID; it does not guess an ID or make a ChatGPT API request.
- Project conversations still require the native action menu because their branch flow uses it.
- Assistant-response preparation errors preserve their actual message. They no longer append a language warning unless the document language is genuinely unsupported.

## Load for testing

1. Open `chrome://extensions` and enable **Developer mode**.
2. Disable the Chrome Web Store SideTalk extension temporarily. Do not remove it or clear its data.
3. Choose **Load unpacked** and select this directory.
4. Use a dedicated test chat. Reload the ChatGPT tab after the extension is loaded.

## Roll back

Disable or remove this unpacked extension from `chrome://extensions`, then re-enable the Store version. This directory does not alter the Store extension or its local storage.

## Validation status

The two targeted source changes and manifest JSON were checked statically. A signed CRX cannot be regenerated from this unpacked copy. Real branch creation, persistence, and recovery still need testing in the authenticated Chrome profile that reproduces the issue.
