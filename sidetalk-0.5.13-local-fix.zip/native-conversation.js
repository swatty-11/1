(() => {
  "use strict";

  const KEY = "__sidetalkNativeConversationCapture";
  const REQUEST_EVENT = "sidetalk:native-conversation:request";
  const RESPONSE_EVENT = "sidetalk:native-conversation:response";
  const existing = window[KEY];
  if (existing?.version === 8) return;
  existing?.dispose?.();
  if (typeof window.fetch !== "function") return;

  const originalFetch = window.fetch;
  const idPattern = /^[A-Za-z0-9_-]{1,128}$/;
  const promptPattern = /^You are now in a new Side Chat branch\. Reply exactly with: BRANCH_READY_[A-Za-z0-9_-]{16,128}$/;
  const replyPattern = /^BRANCH_READY_[A-Za-z0-9_-]{16,128}$/;
  let route = null;
  let routeGeneration = 0;
  let requestOrder = 0;
  let latestRequestOrder = 0;
  let latestTailOrder = 0;
  let snapshot = null;
  let readable = false;
  let capabilityKnown = false;
  let rateLimited = false;
  let rateLimitRequestOrder = 0;
  let retryAfterMs = null;
  let disposed = false;
  const initialRoute = location.href;
  let ownsInitialLoader = false;
  try {
    const navigationUrl = performance.getEntriesByType("navigation")[0]?.name;
    ownsInitialLoader = !existing && document.readyState === "loading" && typeof navigationUrl === "string" &&
      new URL(navigationUrl).href.split("#")[0] === initialRoute.split("#")[0];
  } catch {
    // Only the first document-start installation can attribute hydration data.
  }
  let initialLoaderObserved = false;
  let initialRouteRetired = false;

  function invalidate(preserveRateLimit = false) {
    routeGeneration += 1;
    snapshot = null;
    readable = false;
    if (!preserveRateLimit) {
      rateLimited = false;
      rateLimitRequestOrder = 0;
      retryAfterMs = null;
    }
    latestRequestOrder = 0;
    latestTailOrder = 0;
  }

  function isRecord(value) {
    return value !== null && typeof value === "object" && !Array.isArray(value);
  }

  function isId(value) {
    return typeof value === "string" && idPattern.test(value);
  }

  function currentRoute() {
    const match = location.pathname.match(/^\/(?:g\/([^/]+)\/)?c\/([^/]+)\/?$/);
    if (!match || !isId(match[2])) return null;
    const projectId = match[1] ? /^(g-p-[0-9a-f]{32})(?:-.+)?$/i.exec(match[1])?.[1] || match[1] : null;
    if (projectId && !isId(projectId)) return null;
    return { conversationId: match[2], projectId };
  }

  function refreshRoute() {
    if (location.href !== initialRoute) initialRouteRetired = true;
    const next = currentRoute();
    const nextKey = next ? `${next.projectId || ""}/${next.conversationId}` : "";
    const previousKey = route ? `${route.projectId || ""}/${route.conversationId}` : "";
    if (nextKey !== previousKey) {
      invalidate();
    }
    route = next;
    return next;
  }

  // A cold document can render the generic conversation error from a server
  // loader, without a client-side conversation GET or observable HTTP 429.
  // Observe that existing Promise once; never request or retry it ourselves.
  function observeInitialLoader() {
    if (!ownsInitialLoader || disposed || initialLoaderObserved || initialRouteRetired || location.href !== initialRoute ||
        requestOrder !== 0 || !refreshRoute()) return;
    const conversation = window.__reactRouterContext?.state?.loaderData?.["conversation-layout.route"]?.conversation;
    if (!conversation || typeof conversation.then !== "function") return;
    initialLoaderObserved = true;
    Promise.resolve(conversation).then((value) => {
      refreshRoute();
      if (disposed || initialRouteRetired || location.href !== initialRoute || requestOrder !== 0 ||
          !isRecord(value) || value.status !== "rate_limited") return;
      rateLimited = true;
      readable = false;
      snapshot = null;
      retryAfterMs = typeof value.retryAfterMs === "number" && Number.isFinite(value.retryAfterMs) &&
        value.retryAfterMs >= 0 && value.retryAfterMs <= Number.MAX_SAFE_INTEGER ? value.retryAfterMs : null;
    }).catch(() => {});
  }

  function optionalString(value) {
    return value == null || (typeof value === "string" && value.length <= 128);
  }

  function optionalBoolean(value) {
    return value == null || typeof value === "boolean";
  }

  function normalizeMessage(value) {
    if (!isRecord(value) || !isId(value.id) || !isRecord(value.author) ||
        !["system", "user", "assistant", "tool"].includes(value.author.role) ||
        !isRecord(value.content) || typeof value.content.content_type !== "string" ||
        !value.content.content_type || value.content.content_type.length > 128 ||
        !optionalString(value.status) || !optionalString(value.channel) ||
        !optionalString(value.recipient) || !optionalBoolean(value.end_turn) ||
        (value.metadata != null && !isRecord(value.metadata))) return null;
    if (value.author.role === "user" && value.content.content_type === "text" &&
        (!Array.isArray(value.content.parts) || !value.content.parts.every((part) => typeof part === "string"))) return null;

    const metadata = value.metadata || {};
    if (!optionalBoolean(metadata.is_complete) ||
        (metadata.branching_from_conversation_id != null && !isId(metadata.branching_from_conversation_id))) return null;

    // Native history stays in the page's own data store. Keep only the exact
    // initialization pair needed to verify the branch's identity.
    let text = "";
    const parts = value.content.parts;
    let initializationKind;
    if (value.author.role === "user") {
      initializationKind = "unknown";
      if (value.content.content_type === "text" && Array.isArray(parts) && parts.length &&
          parts.every(part => typeof part === "string")) {
        const candidate = parts.join("\n");
        const normalized = candidate.replace(/\s+/g, " ").trim();
        initializationKind = promptPattern.test(candidate) ? "exact" :
          /Side\s+Chat\s+branch|BRANCH[\s_]*READY/i.test(normalized) ? "bootstrap-like" : "ordinary";
      }
    }
    if (value.content.content_type === "text" && Array.isArray(parts) &&
        parts.every((part) => typeof part === "string") &&
        (value.author.role === "user" || value.author.role === "assistant") &&
        parts.reduce((length, part) => length + part.length + 1, 0) <= 300) {
      const candidate = parts.join("\n");
      if ((value.author.role === "user" && promptPattern.test(candidate)) ||
          (value.author.role === "assistant" && replyPattern.test(candidate))) text = candidate;
    }

    return {
      id: value.id,
      role: value.author.role,
      text,
      ...(initializationKind ? { initializationKind } : {}),
      contentType: value.content.content_type,
      status: value.status ?? null,
      endTurn: value.end_turn === true,
      // Async native answers can omit this flag after a successful final turn.
      // Preserve absence separately from an explicit incomplete value.
      isComplete: metadata.is_complete ?? null,
      // Merged native answers can omit the original fork metadata. Retain
      // only the validated shape, never source IDs as alternative split IDs.
      ...(metadata.is_merged_message === true && Array.isArray(metadata.source_message_ids) &&
        metadata.source_message_ids.length > 1 && metadata.source_message_ids.length <= 128 &&
        metadata.source_message_ids.every(isId) &&
        new Set(metadata.source_message_ids).size === metadata.source_message_ids.length &&
        metadata.continuation_message_id === metadata.source_message_ids.at(-1)
        ? { mergedMessage: true } : {}),
      ...(metadata.branching_from_conversation_id != null
        ? { branchingFromConversationId: metadata.branching_from_conversation_id }
        : {}),
      channel: value.channel ?? null,
      recipient: value.recipient ?? null
    };
  }

  function normalizePage(value, conversationId) {
    if (!isRecord(value) || value.conversation_id !== conversationId ||
        !isId(value.current_node) || !Array.isArray(value.messages) ||
        value.messages.length === 0 || value.messages.length > 50_000 ||
        !isRecord(value.page_info) ||
        typeof value.page_info.has_previous_page !== "boolean" ||
        typeof value.page_info.has_next_page !== "boolean" ||
        (value.gizmo_id != null && !isId(value.gizmo_id)) ||
        (value.conversation_template_id != null && !isId(value.conversation_template_id))) return null;

    const messages = [];
    const ids = new Set();
    for (const message of value.messages) {
      const normalized = normalizeMessage(message);
      if (!normalized || ids.has(normalized.id)) return null;
      ids.add(normalized.id);
      messages.push(normalized);
    }
    if (value.page_info.start_cursor !== messages[0].id ||
        value.page_info.end_cursor !== messages[messages.length - 1].id) return null;

    const projectId = value.gizmo_id || value.conversation_template_id || null;
    // Distinct native project fields are not interchangeable proof.
    if (value.gizmo_id && value.conversation_template_id &&
        value.gizmo_id !== value.conversation_template_id) return null;
    return {
      conversationId,
      projectId,
      currentNode: value.current_node,
      hasPreviousPage: value.page_info.has_previous_page,
      hasNextPage: value.page_info.has_next_page,
      messages
    };
  }

  function projectMatches(page, activeRoute) {
    return !activeRoute.projectId || page.projectId === activeRoute.projectId;
  }

  function mergeEarlierPage(page) {
    if (!snapshot || page.conversationId !== snapshot.conversationId ||
        page.projectId !== snapshot.projectId || page.currentNode !== snapshot.currentNode) return false;
    const overlapStart = page.messages.findIndex((message) => message.id === snapshot.messages[0].id);
    if (overlapStart < 0) return false;
    const overlapLength = page.messages.length - overlapStart;
    if (overlapLength > snapshot.messages.length) return false;
    for (let index = 0; index < overlapLength; index += 1) {
      if (JSON.stringify(page.messages[overlapStart + index]) !== JSON.stringify(snapshot.messages[index])) return false;
    }
    const messages = [...page.messages.slice(0, overlapStart), ...snapshot.messages];
    if (messages.length > 50_000 || new Set(messages.map((message) => message.id)).size !== messages.length) return false;
    snapshot = { ...snapshot, hasPreviousPage: page.hasPreviousPage, messages };
    return true;
  }

  function normalizeBeforePage(value, context) {
    const tail = context.tail;
    if (!context.paginationAllowed || !tail || snapshot !== tail || !tail.hasPreviousPage ||
        tail.hasNextPage !== false || tail.messages.at(-1)?.id !== tail.currentNode ||
        !isId(context.before) || tail.messages[0]?.id !== context.before ||
        !isRecord(value) || !Array.isArray(value.messages) || !value.messages.length || value.messages.length > 50_000 ||
        !isRecord(value.page_info) || typeof value.page_info.has_previous_page !== "boolean" ||
        value.page_info.has_next_page !== true ||
        (value.conversation_id != null && value.conversation_id !== tail.conversationId) ||
        (value.current_node != null && value.current_node !== tail.currentNode) ||
        (value.gizmo_id != null && value.gizmo_id !== tail.projectId) ||
        (value.conversation_template_id != null && value.conversation_template_id !== tail.projectId)) return null;
    const messages = [];
    const ids = new Set(tail.messages.map(message => message.id));
    for (const raw of value.messages) {
      const message = normalizeMessage(raw);
      // The observed before endpoint excludes its cursor. Duplicate or
      // overlapping IDs cannot prove an exclusive adjacent prefix.
      if (!message || ids.has(message.id)) return null;
      ids.add(message.id);
      messages.push(message);
    }
    if (value.page_info.start_cursor !== messages[0].id ||
        value.page_info.end_cursor !== messages.at(-1).id || ids.size > 50_000) return null;
    return { ...tail, hasPreviousPage: value.page_info.has_previous_page,
      messages: [...messages, ...tail.messages] };
  }

  function nativeRequest(input, init) {
    try {
      const method = init?.method || (isRecord(input) || typeof input === "object" ? input?.method : null) || "GET";
      if (typeof method !== "string") return null;
      const inputUrl = typeof input === "string" || input instanceof URL ? input : input?.url;
      if (typeof inputUrl !== "string" && !(inputUrl instanceof URL)) return null;
      const url = new URL(inputUrl, location.href);
      if (url.origin !== location.origin) return null;
      return { url, method: method.toUpperCase() };
    } catch {
      return null;
    }
  }

  function observeResponse(response, context) {
    if (disposed || !response) return;
    const active = refreshRoute();
    if (response.status === 429 && active && active.projectId === context.projectId &&
        active.conversationId === context.conversationId && context.order === rateLimitRequestOrder &&
        response.redirected !== true && (!response.url || response.url === context.url)) {
      rateLimited = true;
      retryAfterMs = null;
      return;
    }
    if (response.ok !== true || typeof response.clone !== "function") return;
    let clone;
    try {
      clone = response.clone();
    } catch {
      return;
    }
    Promise.resolve().then(() => clone.json()).then((value) => {
      const activeRoute = refreshRoute();
      if (disposed || !activeRoute || context.generation !== routeGeneration ||
          activeRoute.conversationId !== context.conversationId ||
          context.order !== latestRequestOrder || context.order < latestTailOrder) return;
      if (context.pagination) {
        if (response.redirected === true) return;
        if (typeof response.url === "string" && response.url) {
          const responseUrl = new URL(response.url, location.href);
          if (responseUrl.href !== context.url) return;
        }
        const merged = normalizeBeforePage(value, context);
        if (!merged || !projectMatches(merged, activeRoute)) return;
        snapshot = merged;
        capabilityKnown = true;
        readable = true;
        return;
      }
      const page = normalizePage(value, context.conversationId);
      if (!page || !projectMatches(page, activeRoute)) return;
      // This document has observed the supported native response shape. The
      // hint survives invalidation, but never makes stale proof readable.
      capabilityKnown = true;
      const isTail = page.hasNextPage === false && page.messages[page.messages.length - 1].id === page.currentNode;
      if (isTail) {
        snapshot = page;
        latestTailOrder = context.order;
        readable = true;
      } else {
        readable = mergeEarlierPage(page);
      }
    }).catch(() => {
      // Reading a clone cannot affect the native request or its consumer.
    });
  }

  function wrappedFetch(...args) {
    const activeRoute = refreshRoute();
    const request = nativeRequest(args[0], args[1]);
    // The observed native batch endpoint uses POST to read turn versions.
    // Its response is left entirely to the native hydration consumer.
    const isNativeReadBatch = request?.method === "POST" &&
      request.url.pathname === "/backend-api/conversations/batch";
    if (request && !["GET", "HEAD"].includes(request.method) &&
        !isNativeReadBatch &&
        /^\/backend-api\/(?:[^/]+\/)*conversations?(?:\/|$)/.test(request.url.pathname)) {
      // A native edit, regeneration, deletion, or send can change the selected
      // path. Forget prior proof without inspecting the write body.
      // A concurrent native composer initialization invalidates association
      // proof, but cannot hide a rate limit on this document's latest read.
      invalidate(true);
    }
    const conversationId = request?.method === "GET"
      ? request.url.pathname.match(/^\/backend-api\/conversations\/([A-Za-z0-9_-]{1,128})(?:\/messages)?\/?$/)?.[1] || null
      : null;
    const context = conversationId && activeRoute?.conversationId === conversationId
      ? { conversationId, projectId: activeRoute.projectId, generation: routeGeneration, order: ++requestOrder,
          url: request.url.href,
          pagination: /\/messages\/?$/.test(request.url.pathname),
          paginationAllowed: request.url.searchParams.getAll("before").length === 1 &&
            [...request.url.searchParams.keys()].every(key => ["before", "num_turns", "include_has_versions"].includes(key)),
          before: request.url.searchParams.get("before"), tail: snapshot }
      : null;
    if (context) {
      latestRequestOrder = context.order;
      rateLimitRequestOrder = context.order;
      // Keep the normalized prior tail privately for pagination overlap, but
      // never expose it while a newer native load is pending or unverified.
      readable = false;
      rateLimited = false;
      retryAfterMs = null;
    }
    const promise = Reflect.apply(originalFetch, this, args);
    if (context && promise && typeof promise.then === "function") {
      promise.then((response) => observeResponse(response, context), () => {}).catch(() => {});
    }
    return promise;
  }

  // Read the exact action requested by the isolated world, never a page-level
  // last button. Only IDs cross the bridge; native transcript text stays private.
  function actionBranchPoint(index, conversationId) {
    const result = { latestAssistantMessageId: null, renderedAssistantMessageId: null };
    const button = document.querySelectorAll("button")[index];
    if (!button || !/^(?:more actions|更多操作)$/i.test((button.getAttribute("aria-label") || button.textContent || "").replace(/\s+/g, " ").trim())) return result;
    const uuid = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;
    for (const key of Object.keys(button).filter(key => key.startsWith("__reactFiber$") || key.startsWith("__reactInternalInstance$"))) {
      let fiber = button[key];
      let actionId = null;
      for (let depth = 0; fiber && depth < 50; depth += 1, fiber = fiber.return) {
        const props = fiber.memoizedProps;
        if (!isRecord(props)) continue;
        if (Object.prototype.hasOwnProperty.call(props, "isMostRecentTurn")) {
          // Stop at the nearest owning answer. A page/container's later
          // latest-message property can never authorize an older action.
          const item = props.assistantItem;
          if (actionId && props.conversationId === conversationId && props.isMostRecentTurn === true &&
              isRecord(item) && item.completed === true && item.messageId === actionId && item.latestMessageId === actionId) {
            result.latestAssistantMessageId = actionId;
          }
          result.renderedAssistantMessageId = actionId;
          return result;
        }
        if (!actionId && typeof props.onBranch === "function") {
          if (props.conversationId !== conversationId || props.branchDisabled !== false ||
              typeof props.messageId !== "string" || !uuid.test(props.messageId)) return result;
          actionId = props.messageId;
        }
      }
    }
    return result;
  }

  function respond(event) {
    if (disposed || typeof event.detail !== "string" || event.detail.length > 512) return;
    let request;
    try {
      request = JSON.parse(event.detail);
    } catch {
      return;
    }
    if (!isRecord(request) || !isId(request.requestId)) return;
    const activeRoute = refreshRoute();
    observeInitialLoader();
    const current = readable && activeRoute && snapshot &&
      activeRoute.conversationId === snapshot.conversationId && projectMatches(snapshot, activeRoute)
      ? snapshot : null;
    document.dispatchEvent(new CustomEvent(RESPONSE_EVENT, {
      detail: JSON.stringify({
        requestId: request.requestId,
        snapshot: current,
        dataAvailable: current !== null,
        capabilityKnown,
        ...(activeRoute && Number.isInteger(request.branchPointButtonIndex) && request.branchPointButtonIndex >= 0 && request.branchPointButtonIndex < 20000 ? {
          branchPoint: { conversationId: activeRoute.conversationId, ...actionBranchPoint(request.branchPointButtonIndex, activeRoute.conversationId) }
        } : {}),
        ...(rateLimited && activeRoute ? { rateLimited: true, ...(retryAfterMs !== null ? { retryAfterMs } : {}) } : {})
      })
    }));
  }

  refreshRoute();
  observeInitialLoader();
  window.fetch = wrappedFetch;
  document.addEventListener("DOMContentLoaded", observeInitialLoader);
  window.addEventListener("load", observeInitialLoader);
  document.addEventListener(REQUEST_EVENT, respond);
  window.addEventListener("popstate", refreshRoute);
  const historyBridges = [];
  for (const method of ["pushState", "replaceState"]) {
    const original = history[method];
    const wrapper = function (...args) {
      const result = Reflect.apply(original, this, args);
      refreshRoute();
      return result;
    };
    try {
      history[method] = wrapper;
      historyBridges.push({ method, original, wrapper });
    } catch {
      // Fetch and request-event route checks remain available if a page locks
      // its History methods. Native navigation behavior is never replaced.
    }
  }
  const capture = {
    version: 8,
    dispose() {
      if (disposed) return;
      disposed = true;
      snapshot = null;
      readable = false;
      if (window.fetch === wrappedFetch) window.fetch = originalFetch;
      document.removeEventListener(REQUEST_EVENT, respond);
      document.removeEventListener("DOMContentLoaded", observeInitialLoader);
      window.removeEventListener("load", observeInitialLoader);
      window.removeEventListener("popstate", refreshRoute);
      for (const { method, original, wrapper } of historyBridges) {
        try {
          if (history[method] === wrapper) history[method] = original;
        } catch {
          // A later page wrapper may have locked the method after installation.
        }
      }
      if (window[KEY] === capture) delete window[KEY];
    }
  };
  window[KEY] = capture;
})();
