(() => {
  const BRIDGE_KEY = "__chatgptSideBranchIframeNavigation";
  const BOOTSTRAP_WINDOW_NAME_PREFIX = "__chatgptSideBranchBootstrap:";
  const PROJECT_HANDOFF_ARM_EVENT =
    "chatgpt-side-branch:arm-project-branch-handoff";
  const PROJECT_HANDOFF_DISARM_EVENT =
    "chatgpt-side-branch:disarm-project-branch-handoff";
  const branchRoute = /^\/branch\/[^/]+\/[^/]+\/?$/i.test(
    window.location.pathname
  );
  const ownsTopLevelBootstrap =
    !window.frameElement &&
    window.name.startsWith(BOOTSTRAP_WINDOW_NAME_PREFIX);

  // A tiny local extension page sets window.name before navigating here. The
  // marker therefore exists before any ChatGPT script can perform its blank-
  // popup handoff, without first loading a throwaway ChatGPT home shell. Clear
  // the marker as soon as the transaction leaves the native Branch route.
  if (ownsTopLevelBootstrap && !branchRoute) {
    window.name = "";
    return;
  }

  // Project Branches cannot use the deterministic /branch/... route. ChatGPT
  // creates their tab-local draft from the active parent page and currently
  // hands it off through window.open()/target=_blank. Programmatic menu clicks
  // do not reliably retain popup permission, so arm a short-lived, one-shot
  // bridge only while the extension owns that exact native menu transaction.
  // The activated creation copy becomes the draft owner. The background can
  // then return to the unchanged original parent after the first send.
  if (!branchRoute && !window.frameElement) {
    const previousBridge = window[BRIDGE_KEY];
    previousBridge?.dispose?.();

    const nativeOpen = window.open.bind(window);
    const nativeAssign = window.location.assign.bind(window.location);
    let armed = false;
    let disarmTimer = 0;
    let bridge = null;

    const branchDestination = (value) => {
      if (value === undefined || value === null || value === "") return null;
      try {
        const url = new URL(String(value), window.location.href);
        if (url.origin !== window.location.origin) return null;
        if (url.username || url.password) return null;
        const projectPath = /^\/g\/([^/]+)\/c\/[^/]+\/?$/i.exec(url.pathname);
        const sourceProject = /^\/g\/([^/]+)\/c\//i.exec(window.location.pathname);
        const projectIdentity = (segment) => segment.replace(/^(g-p-[0-9a-f]{32})(?:-.+)?$/i, "$1").toLowerCase();
        if (projectPath && sourceProject && projectIdentity(projectPath[1]) === projectIdentity(sourceProject[1])) {
          return url;
        }
        return /^\/(?:c|branch)\//i.test(url.pathname) ? url : null;
      } catch {
        return null;
      }
    };

    const navigate = (url) => {
      armed = false;
      window.clearTimeout(disarmTimer);
      nativeAssign(url.href);
      return window;
    };

    const projectOpen = (url, target, features) => {
      if (!armed) return nativeOpen(url, target, features);
      const destination = branchDestination(url);
      if (destination) return bridge.navigate(destination);

      // ChatGPT can open an empty WindowProxy and assign its local-chatgpt:
      // destination afterward. Returning this Window makes that assignment
      // navigate the exact active source instead of requiring a popup.
      if (url === undefined || url === null || url === "") {
        armed = false;
        window.clearTimeout(disarmTimer);
        return window;
      }
      return nativeOpen(url, target, features);
    };

    const captureProjectBlankTarget = (event) => {
      if (!armed) return;
      const target = event.target;
      const anchor = target instanceof Element ? target.closest("a[href]") : null;
      if (!(anchor instanceof HTMLAnchorElement)) return;
      if ((anchor.target || "").toLowerCase() !== "_blank") return;
      const destination = branchDestination(anchor.href);
      if (!destination) return;
      event.preventDefault();
      event.stopImmediatePropagation();
      bridge.navigate(destination);
    };

    const disarm = () => {
      armed = false;
      window.clearTimeout(disarmTimer);
      window.open = nativeOpen;
      document.removeEventListener("click", captureProjectBlankTarget, true);
    };

    const arm = () => {
      disarm();
      armed = true;
      window.open = projectOpen;
      document.addEventListener("click", captureProjectBlankTarget, true);
      disarmTimer = window.setTimeout(disarm, 20_000);
    };

    const dispose = () => {
      disarm();
      document.removeEventListener(PROJECT_HANDOFF_ARM_EVENT, arm, true);
      document.removeEventListener(PROJECT_HANDOFF_DISARM_EVENT, disarm, true);
      delete window[BRIDGE_KEY];
    };

    document.addEventListener(PROJECT_HANDOFF_ARM_EVENT, arm, true);
    document.addEventListener(PROJECT_HANDOFF_DISARM_EVENT, disarm, true);
    bridge = { nativeOpen, navigate, dispose };
    window[BRIDGE_KEY] = bridge;
    return;
  }
  if (!branchRoute || (!window.frameElement && !ownsTopLevelBootstrap)) {
    return;
  }

  const previousBridge = window[BRIDGE_KEY];
  previousBridge?.dispose?.();

  const nativeOpen = window.open.bind(window);
  const nativeAssign = window.location.assign.bind(window.location);

  const branchDestination = (value) => {
    if (value === undefined || value === null || value === "") return null;
    try {
      const url = new URL(String(value), window.location.href);
      if (url.origin !== window.location.origin) return null;
      return /^\/(?:c|branch)\//i.test(url.pathname) ? url : null;
    } catch {
      return null;
    }
  };

  const stayInIframe = (url) => {
    nativeAssign(url.href);
    return window;
  };

  const bridge = {
    nativeOpen,
    navigate: stayInIframe,
    dispose() {
      document.removeEventListener("click", captureBlankTarget, true);
      window.open = nativeOpen;
      delete window[BRIDGE_KEY];
    }
  };

  window.open = (url, target, features) => {
    const destination = branchDestination(url);
    if (destination) return bridge.navigate(destination);

    // ChatGPT can first open an empty browsing context and assign the local
    // draft URL to the returned WindowProxy. Returning this iframe makes that
    // subsequent assignment navigate the Side Chat surface instead of
    // creating a browser tab.
    if (url === undefined || url === null || url === "") return window;
    return nativeOpen(url, target, features);
  };

  const captureBlankTarget = (event) => {
    const target = event.target;
    const anchor = target instanceof Element ? target.closest("a[href]") : null;
    if (!(anchor instanceof HTMLAnchorElement)) return;
    if ((anchor.target || "").toLowerCase() !== "_blank") return;
    const destination = branchDestination(anchor.href);
    if (!destination) return;
    event.preventDefault();
    event.stopImmediatePropagation();
    bridge.navigate(destination);
  };
  document.addEventListener("click", captureBlankTarget, true);

  window[BRIDGE_KEY] = bridge;
})();
